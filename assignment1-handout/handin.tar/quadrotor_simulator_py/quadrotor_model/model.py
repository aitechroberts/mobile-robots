#!/usr/bin/env python
import numpy as np
import yaml
import scipy
from scipy import integrate
from numpy import matmul

from quadrotor_simulator_py.quadrotor_control.state import State
from quadrotor_simulator_py.quadrotor_model.mixer import QuadMixer
from quadrotor_simulator_py.utils.quaternion import Quaternion
from quadrotor_simulator_py.utils.pose import Pose
from quadrotor_simulator_py.utils.pose import Rot3


class RPMParameters:
    min = 0.0
    max = 0.0

    def __init__(self):
        pass

    def __repr__(self):
        return ('RPMParameters\n' +
                'min:' + str(self.min) + '\n' +
                'max:' + str(self.max) + '\n')


class ModelParameters:

    def __init__(self):
        self.gravity_norm = 9.81
        self.mass = 2.0
        self.rpm_params = RPMParameters()
        self.mixer = np.zeros((4, 6))
        self.inertia = np.zeros((3, 3))
        self.inertia_inv = np.zeros((3, 3))
        self.aw = np.zeros((3, 1))
        self.ang_acc = np.zeros((3, 1))
        self.uRPM = np.zeros((4, 1))

        self.kmotor_u = 0.0
        self.kmotor_d = 0.0

        # _motor_model(0) * (RPM)^2 + _motor_model(1)*(RPM) + _motor_model(2)
        self.motor_model = np.zeros((3, 1))

        # _cg_offset is the position vector from center of gravity to geometric center.
        self.cg_offset = np.zeros((3, 1))

    def __repr__(self):
        return ('ModelParameters\n' +
                'gravity norm:\t\t' + str(self.gravity_norm) + '\n' +
                'mass:\t\t\t' + str(self.mass) + '\n' +
                'mixer:\n' + np.array2string(self.mixer) + '\n' +
                'inertia:\n' + np.array2string(self.inertia) + '\n' +
                'inertia_inv:\n' + np.array2string(self.inertia_inv) + '\n' +
                'aw:\t\t\t' + np.array2string(np.transpose(self.aw)) + '\n' +
                'ang_acc:\t\t' + np.array2string(np.transpose(self.ang_acc)) + '\n' +
                'uRPM:\t\t\t' + np.array2string(np.transpose(self.uRPM)) + '\n' +
                'kmotor_u:\t\t\t' + str(self.kmotor_u) + '\n' +
                'kmotor_d:\t\t\t' + str(self.kmotor_d) + '\n\n' +
                self.rpm_params.__repr__()
                )


class QuadrotorModel:
    def __init__(self):
        self.mixer = QuadMixer()

        self.Twb = Pose()

        self.vw = np.zeros((3, 1))
        self.aw = np.zeros((3, 1))
        self.wb = np.zeros((3, 1))
        self.ang_acc = np.zeros((3, 1))
        self.rs = np.zeros((4, 1))

        self.model_params = ModelParameters()
        self.rpm_params = RPMParameters()

        self.num_rotors = 4
        self.time = 0.0
        self.tstart = 0.0
        self.zoffset = 0.0

        self.use_cm_offset = True
        self.enable_rotor_inertia = True

    def initialize(self, yaml_file):

        data = []
        with open(yaml_file, 'r') as stream:
            try:
                data = yaml.safe_load(stream)
            except yaml.YamlError as exc:
                print(exc)

            self.model_params.mass = data['mass']
            self.model_params.gravity_norm = data['gravity_norm']

            tmp1 = np.zeros((3, 3))
            tmp2 = np.zeros((3, 3))
            tmp1[0, 0] = data['inertia']['Ixx']
            tmp1[1, 1] = data['inertia']['Iyy']
            tmp1[2, 2] = data['inertia']['Izz']
            tmp2[0, 1] = data['inertia']['Ixy']
            tmp2[0, 2] = data['inertia']['Ixz']
            tmp2[1, 2] = data['inertia']['Iyz']
            self.model_params.inertia = tmp1 + tmp2 + np.transpose(tmp2)
            self.model_params.inertia_inv = np.linalg.inv(
                self.model_params.inertia)

            self.model_params.motor_model[0] = data['rotor']['cT2']
            self.model_params.motor_model[1] = data['rotor']['cT1']
            self.model_params.motor_model[2] = data['rotor']['cT0']

            self.model_params.kmotor_u = data['rotor']['time_constant']
            self.model_params.kmotor_d = data['rotor']['time_constant']

            self.zoffset = data['zoffset']

            # TODO: Fix in next iteration
            self.model_params.cg_offset[0] = 0.0
            self.model_params.cg_offset[1] = 0.0
            self.model_params.cg_offset[2] = 0.0

            self.model_params.rpm_params.min = data['rpm']['min']
            self.model_params.rpm_params.max = data['rpm']['max']

            self.num_rotors = 4

            self.mixer.initialize(yaml_file)
            self.model_params.mixer = self.mixer.construct_mixer()

            self.enable_rotor_inertia = data['rotor']['enable_inertia']

    def __repr__(self):
        return ('QuadrotorModel\n' +
                'Twb:\n' + np.array2string(self.Twb.get_se3().as_matrix()) + '\n' +
                'vw:' + np.array2string(np.transpose(self.vw)) + '\n' +
                'aw:' + np.array2string(np.transpose(self.aw)) + '\n' +
                'wb:' + np.array2string(np.transpose(self.wb)) + '\n' +
                'ang_acc:' + np.array2string(np.transpose(self.ang_acc)) + '\n' +
                'rs:' + np.array2string(np.transpose(self.rs)) + '\n' +
                'num_rotors:\t\t\t' + str(self.num_rotors) + '\n' +
                'time:\t\t\t\t' + str(self.time) + '\n' +
                'tstart:\t\t\t\t' + str(self.tstart) + '\n' +
                'zoffset:\t\t\t' + str(self.zoffset) + '\n' +
                'use cm offset:\t\t\t' + str(self.use_cm_offset) + '\n' +
                self.model_params.__repr__()
                )

    def reset_simulation(self):
        self.model_params.uRPM = np.zeros((4, 1))
        self.set_pose(np.array([0, 0, 0, 1, 0, 0, 0]))
        self.vw = np.zeros((3, 1))
        self.aw = np.zeros((3, 1))
        self.aw[2, 0] = -self.model_params.gravity_norm
        self.wb = np.zeros((3, 1))
        self.rs = np.zeros((4, 1))
        self.time = 0.0

    def apply_command(self, uRPM):
        self.model_params.uRPM = uRPM

    def gravity_norm(self):
        return self.model_params.gravity_norm

    def get_pose(self):
        return self.Twb

    def set_pose(self, Twb):
        self.Twb = Pose(Twb)

    def calculate_force_and_torque_from_rpm(self, rpms):
        """ Calculates the scalar force and torques from RPM using
                the motor model within this class object.
        Args:
            rpms: These are the RPM values.
        Output:
            F: scalar value that represents force
            M: 3x1 numpy array representing torques
        """

        # Motor model: force_i = cT2 * rpm_i^2 + cT1 * rpm_i + cT0
        # This quadratic maps each rotor's RPM to the thrust it produces.
        cT2 = self.model_params.motor_model[0, 0]
        cT1 = self.model_params.motor_model[1, 0]
        cT0 = self.model_params.motor_model[2, 0]

        rotor_forces = np.zeros((4, 1))
        for i in range(4):
            rotor_forces[i, 0] = cT2 * rpms[i]**2 + cT1 * rpms[i] + cT0

        # Mixer converts [f1,f2,f3,f4] -> [total_thrust, tau_x, tau_y, tau_z]
        wrench = self.model_params.mixer @ rotor_forces
        F = wrench[0, 0]
        M = wrench[1:4]

        return F, M

    def quaternion_derivative(self, qn, wb):
        """ Calculates the derivative of the quaternion given
            an input quaternion (qn) and angular velocities (wb)

        Args:
            qn: Quaternion object
            wb: 3x1 numpy array representing body-frame angular velocities

        Output:
            dq: 4x1 numpy array representing the derivative of the quaternion
        """

        # Quaternion derivative: dq/dt = (1/2) * Omega(w) * q
        # where Omega is the 4x4 skew-like matrix built from body angular velocity.
        # q = [w, x, y, z] convention. Uses the RAW (unnormalized) quaternion
        # so the ODE integrator's state stays consistent (normalize only for rotation matrix).
        wx = wb[0, 0]
        wy = wb[1, 0]
        wz = wb[2, 0]

        Omega = np.array([
            [ 0,  -wx, -wy, -wz],
            [ wx,  0,   wz, -wy],
            [ wy, -wz,  0,   wx],
            [ wz,  wy, -wx,  0 ]
        ])

        q = np.array([[qn.w()], [qn.x()], [qn.y()], [qn.z()]])
        dq = 0.5 * Omega @ q

        return dq

    def calculate_world_frame_linear_acceleration(self, model, ang_acc, wb, Rwb, u1):
        """ Calculates the linear acceleration of the aerial robot.
                Hint: Use Equation (4.2) of Daniel Mellinger's PhD thesis
                "Trajectory Generation and Control for Quadrotors"

        Args:
            model: These are the self.model_params. This will give you the
                offset of the center of mass in body frame coordinates (r_{off})
            ang_acc: 3x1 numpy array representing angular acceleration
            wb: 3x1 numpy array representing body-frame angular velocities
            Rwb: 3x3 numpy matrix representing rotation
            u1: scalar representing vehicle thrust

        Output:
            lin_acc: 3x1 numpy array representing linear acceleration
        """

        # Mellinger Eq 4.2: world-frame linear acceleration with CG offset.
        #   a_w = -g*e3 + (F/m)*R*e3 + R*(r_off x alpha) + R*(w x (w x r_off))
        # Term 1: gravity pointing down
        # Term 2: thrust along body z, rotated to world
        # Term 3: tangential acceleration from angular acceleration at CG offset
        # Term 4: centripetal acceleration from angular velocity at CG offset
        g = model.gravity_norm
        m = model.mass
        r_off = np.reshape(model.cg_offset, (3, 1))
        e3 = np.array([[0], [0], [1]])
        Rwb = np.array(Rwb)
        wb = np.reshape(wb, (3, 1))
        ang_acc = np.reshape(ang_acc, (3, 1))

        lin_acc = (-g * e3
                   + (u1 / m) * Rwb @ e3
                   + Rwb @ np.cross(r_off, ang_acc, axis=0)
                   + Rwb @ np.cross(wb, np.cross(wb, r_off, axis=0), axis=0))

        return lin_acc

    def calculate_angular_acceleration(self, model, moments, wb, Fdes):
        """ Calculates the vehicle angular acceleration.
                Hint: Use Equation (4.3) of Daniel Mellinger's PhD thesis
                "Trajectory Generation and Control for Quadrotors"

        Args:
            model: These are the self.model_params. This will give you the
                offset of the center of mass in body frame coordinates (r_{off})
            moments: 3x1 numpy array representing the moments
            wb: 3x1 numpy array representing body-frame angular velocities
            Fdes: 3x1 numpy array representing [0, 0, F]

        Output:
            ang acc: 3x1 numpy array representing angular acceleration
        """

        # Mellinger Eq 4.3: body-frame angular acceleration with CG offset.
        #   alpha = I^{-1} * (M - w x Iw - w x (r_off x F) + r_off x m*g*e3)
        # Term 1: applied torques from rotors
        # Term 2: gyroscopic / Coriolis torque
        # Term 3: torque from thrust acting at offset CG
        # Term 4: gravity torque from offset CG
        I = model.inertia
        I_inv = model.inertia_inv
        r_off = np.reshape(model.cg_offset, (3, 1))
        wb = np.reshape(wb, (3, 1))
        moments = np.reshape(moments, (3, 1))
        Fdes = np.reshape(Fdes, (3, 1))

        ang_acc = I_inv @ (moments
                           - np.cross(wb, I @ wb, axis=0)
                           - np.cross(wb, np.cross(r_off, Fdes, axis=0), axis=0)
                           + np.cross(r_off, np.array([[0], [0], [model.mass * model.gravity_norm]]), axis=0))

        return ang_acc

    def ode_step(self, t, x):
        """ Numerically integrates the robot dynamics given an initialize
                condition.

            Don't forget to set self.model_params.aw and self.model_params.ang_acc
                inside this function.

        Args:
            t: interval over which to integrate [tstart, tstop]
            x: 1x17 numpy array representing the following
                x[0:3]: translation
                x[3:7]: orientation represented as quaternion
                x[7:10]: linear velocity (world frame)
                x[10:13]: body-frame angular velocity
                x[13:17]: rotor speeds (in RPM)

        Output:
            xdot: 1x17 numpy array containing the following
                xdot[0:3]: world frame linear velocity
                xdot[3:7]: derivative of quaternion
                xdot[7:10]: linear acceleration (world frame)
                xdot[10:13]: angular acceleration (body frame)
                xdot[13:17]: derivative of rotor speeds
        """

        pos = x[0:3]
        quat = x[3:7]
        vel = x[7:10]
        wb = np.reshape(x[10:13], (3, 1))
        rpms = x[13:17]

        # Use raw quaternion for derivative (ODE consistency), normalized for rotation matrix
        qn_raw = Quaternion(quat)
        qn_norm = Quaternion(quat).normalize()
        Rwb = Rot3.from_quat(qn_norm).R

        # First-order motor dynamics: drpm/dt = k_motor * (rpm_cmd - rpm_current)
        kmotor = self.model_params.kmotor_u
        uRPM = np.reshape(self.model_params.uRPM, (4,))
        drpm = kmotor * (uRPM - rpms)

        # When rotor inertia is disabled, motors respond instantly:
        # use the commanded RPMs directly for force/torque calculation.
        if self.enable_rotor_inertia:
            rpms_for_force = rpms
        else:
            rpms_for_force = uRPM

        F, M = self.calculate_force_and_torque_from_rpm(rpms_for_force)

        Fdes = np.array([[0], [0], [F]])

        ang_acc = self.calculate_angular_acceleration(
            self.model_params, M, wb, Fdes)

        aw = self.calculate_world_frame_linear_acceleration(
            self.model_params, ang_acc, wb, Rwb, F)

        dq = self.quaternion_derivative(qn_raw, wb)

        self.model_params.aw = aw
        self.model_params.ang_acc = ang_acc

        xdot = np.zeros(17)
        xdot[0:3] = vel
        xdot[3:7] = dq.flatten()
        xdot[7:10] = aw.flatten()
        xdot[10:13] = ang_acc.flatten()
        xdot[13:17] = drpm

        return xdot

    def _saturate_rpms(self, p, rpm_in):
        rpms = np.zeros((4, 1))
        for i in range(0, 4):
            rpms[i] = np.max(np.min(rpm_in[0], p.max), p.min)
        return rpms

    def update(self, t):

        tstart = self.time
        tstop = t
        t_span = [tstart, tstop]

        ss = np.zeros((17))

        ss[0:3] = self.get_pose().translation().flatten()
        ss[3:7] = self.get_pose().quaternion().flatten()
        ss[7:10] = np.transpose(self.vw).flatten()
        ss[10:13] = np.transpose(self.wb).flatten()
        ss[13:17] = np.transpose(self.rs).flatten()

        sol = integrate.solve_ivp(self.ode_step, t_span, ss)
        self.time = tstop

        ss = sol.y[:, -1]
        self.set_pose(ss[0:7])
        self.vw = ss[7:10]
        self.wb = ss[10:13]

        if self.enable_rotor_inertia:
            self.rs = ss[13:17]
        else:
            self.rs = self.model_params.uRPM

        self.aw = self.model_params.aw
        self.ang_acc = self.model_params.ang_acc

        self.check_collision()

    def check_collision(self):
        if self.Twb.translation()[2] <= self.zoffset:
            self.Twb.set_translation(np.array([0, 0, self.zoffset]))
            self.vw = np.array([0, 0, 0])
            self.wb = np.array([0, 0, 0])
            self.aw = np.array([0, 0, -self.model_params.gravity_norm])
            self.ang_acc = np.array([0, 0, 0])

    def get_state(self):
        s = State()
        s.pos = np.reshape(self.get_pose().translation(), (3, 1))
        s.vel = np.reshape(self.vw, (3, 1))
        s.acc = np.reshape(self.aw, (3, 1))
        s.rot = self.get_pose().get_so3()
        s.angvel = np.reshape(self.wb, (3, 1))
        s.angacc = np.reshape(self.ang_acc, (3, 1))
        s.yaw = Rot3(self.get_pose().get_so3()).yaw()
        return s
